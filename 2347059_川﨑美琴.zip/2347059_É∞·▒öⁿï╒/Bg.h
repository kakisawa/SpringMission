#pragma once
class Bg
{
};

